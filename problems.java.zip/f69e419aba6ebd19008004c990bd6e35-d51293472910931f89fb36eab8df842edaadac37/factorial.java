public class factorial {
    public static void main(String[] args) {
        int n =10 ,product=1;
            for (int i =1; i<=n; i++){
                product=product*i;
                System.out.println(product);
                System.out.println();
            }

    }
}
