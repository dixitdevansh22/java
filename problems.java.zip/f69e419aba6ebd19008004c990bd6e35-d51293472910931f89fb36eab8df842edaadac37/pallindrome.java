public class palindrome {
    public static void main(String [] Args){
        int num = 141,last,rev=0;
        int unreal=num;
        while(unreal!=0){
            last=unreal%10;
            rev=(rev*10)+last;
            unreal=unreal/10;

        }
        if(rev==num)
            System.out.println("PALINDROME NUMBER");
        else
            System.out.println(" NOT A PALINDROME NUMBER");
    }
}