public class oops {
    public static void main(String[] args) {
     int a = 16;
     int b = 8;
     String k = a>b?"1":"0";
        System.out.println(k);


    }



}
//wrt a program to print n natural numbers (even no)using for loop?
//wrt a program to print a table?
//wrt a program to print reverse a number?
//wrt a program to check a number is pallindrome or not?
//wrt a program to print ISt and second?
