import java.util.Scanner;

public class table {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int ans = 0;
        System.out.println("enter a number to print its table:");
        int num = in.nextInt();
        for (int i = 0; i <= 10; i++)
            {
            ans= num*i;
            System.out.println(num + " X " + i+ " = " + ans);
            }
        }

    }
