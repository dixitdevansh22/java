public class firstndlast {
            public static void main(String [] Args){
                int num = 141,last,rev=0,first,last1;
                int oppos=num;
                while(oppos!=0){
                    last=oppos%10;
                    rev=(rev*10)+last;
                    oppos=oppos/10;

                }
                first=rev%10;
                last1=num%10;
                System.out.println("FIRST DIGIT = " +first);
                System.out.println("LAST DIGIT = " +last1);

            }
        }
    }

}
