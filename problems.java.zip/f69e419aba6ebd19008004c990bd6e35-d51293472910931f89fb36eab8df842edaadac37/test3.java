public class test3 {
    public static void main(String[] args) {
        int p= 1000, r=8,t=9;
        int si=(p*r*t)/100;
        System.out.println("simmple interest = "+si);


    }

}
